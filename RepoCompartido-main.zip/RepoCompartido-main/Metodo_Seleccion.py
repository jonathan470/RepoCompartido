def SelectionSort(array=[
    {"name": "Camila", "code": 1},
    {"name": "Daniel", "code": 2},
    {"name": "Sofía", "code": 3},
    {"name": "Juan", "code": 4},
    {"name": "Valentina", "code": 5},
    {"name": "Carlos", "code": 6},
    {"name": "Isabella", "code": 7},
    {"name": "Andrés", "code": 8},
    {"name": "Mariana", "code": 9},
    {"name": "Felipe", "code": 10}
    ]): #Primero se define la funcion con su nombre, en este caso se llama SelectionSort y le ingresamos los valores al arreglo
    N = len(array) #con el len buscamos obtener el tamaño de la lista y se almacena en la variable N
    i = 0 #inicializamos la variable i en 0, este representa la posicion donde inicia
    while i < N - 1: #este ciclo lo que hace es que va operando hasta la penultima posicion, ya que la ultima con las interaciones anteriores ya estara ordenado
        min_idx = i #el min_idx lo que hace es almacenar el indice mas pequeño encontrado
        j=i+1 #la j lo que hace es ir pasando a la siguiente posicion, este sera el punto de partida para seguir ordenando la lista
        while j < N: #este ciclo lo que hace es recorrer desde j hasta la ultima posicion para encontrar el minimo elemento
            if array[j] ["name"] < array[min_idx]["name"]: #Se compara los nombres en orden alfabetico y realiza el intercambio si es necesario
                min_idx=j #aqui lo que hace es ir guardando el nombre minimo en este caso en orden alfabetico

            j=j+1# incremanta j para seguir comparando las otras posiciones
        if min_idx != i: #significa que el elemento ya está correctamente colocado, así que no es necesario hacer nada.
            temp = array[i] #aqui lo que hace es guardar el valor actual que está en la posición i
            array[i]= array[min_idx]# aqui lo que hace es reemplazar el valor de i con el mínimo encontrado en min_idx
            array[min_idx] = temp #cambia el valor original almacenado en temp en la posición del mínimo.
        i = i+1 #incrementa i para mover el inicio de la parte no ordenada

    return array #retorna el array ya ordenado
    
print(SelectionSort()) # imprime en pantalla el array ya ordenado