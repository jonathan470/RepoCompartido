def Burblesort(Array = [
    {"name": "Camila", "code": 1},
    {"name": "Daniel", "code": 2},
    {"name": "Sofía", "code": 3},
    {"name": "Juan", "code": 4},
    {"name": "Valentina", "code": 5},
    {"name": "Carlos", "code": 6},
    {"name": "Isabella", "code": 7},
    {"name": "Andrés", "code": 8},
    {"name": "Mariana", "code": 9},
    {"name": "Felipe", "code": 10}
    ]): # Declaramos la funcion Burblesort y le asignamos datos a la lista
    N = len(Array) #Obtenemos el tamaño de la lista y lo almacenamos en la variable N
    i = 0 #Asignamos a una variable i el valor de 0
    while i < N - 1: #Declaramos una ciclo while donde se cumpla la condicion si i es menor al tamaño de la lista menos una posicion
        j = 0 #Asignamos a una variable j el valor de 0 dentro del ciclo while
        while j < N - i - 1: # declaramos otro ciclo while donde se cumpla si j en menos añ tamaño de la lista menos la variable  i menos una posicion
            #Comparamos los nombres en orden alfabético y realizamos el intercambio si es necesario.
            if Array[j]["name"] > Array[j + 1]["name"]:
                temp = Array[j]
                Array[j] =  Array[j + 1]
                Array[j + 1] = temp
            j = j + 1 # Incrementamos j en cada iteración.
        i = i + 1 # Incrementamos i en cada iteración del bucle externo
    return Array # Retornamos la lista ordenada.
print(Burblesort()) # Llamamos la funcion y imprimios el resultado final