def Insertion_Sort():#Llamamos a la función Insertion Sort la cual nos permitirá ordenar los datos que se encuentran dentro de la función.
    array = [
        {"name": "Camila", "code": 1},
        {"name": "Daniel", "code": 2},
        {"name": "Sofía", "code": 3},
        {"name": "Juan", "code": 4},
        {"name": "Valentina", "code": 5},
        {"name": "Carlos", "code": 6},
        {"name": "Isabella", "code": 7},
        {"name": "Andrés", "code": 8},
        {"name": "Mariana", "code": 9},
        {"name": "Felipe", "code": 10}
    ]#Esta es la lista array de diccionarios, donde se esta representando con los nombres de la personas(name) y un codigo(code), la cual ordenaremos alfabeticamente los nombres.
    
    N=len(array) #Calculamos el valor de N que es igual a la cantidad de elementos que hay en el array
    i=1 #Posición con la cual iniciaremos
    #En Insertion Sort asumimos que el primer elemento (i = 0) ya está ordenado, así que comenzamos desde el segundo.
    while i < N: #Entramos en el bucle while comenzando desde la posición 1(ó sea en la segunda posición de la lista), hasta llegar a la ultima (i = N - 1).
        current = array[i] #Guardamos el elemento que se considera que esta en su posición correcta
        j = i-1 #Se usa en el caso de que el elemento al lado izquierdo de Current sea menor que esté, si es asi, moverlo
        while j >=0 and array[j]["name"] > current["name"]: #Aqui comparamos los nombres alfabéticamente, la condición significa que current debería estar atras de array[j], entonces movemos a current a la derecha una posición 
            array[j+1]=array[j] #Movemos el elemento array[j] una posición a la derecha y actualiza su posición
            j = j-1 #Reducimos j para seguir comparando con los elementos anteriores.
        array[j+1]=current #Cuando encontramos la direccion correcta, insertamos current en su lugar
        i += 1 #Aumentamos 1 para procesar el siguiente elemento de la lista 
    return array #Devolvemos ya la lista ordenada

nueva_lista = Insertion_Sort()
print(nueva_lista)